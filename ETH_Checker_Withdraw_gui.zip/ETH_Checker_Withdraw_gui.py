import webbrowser
import os
from colorama import init, Fore

init()

url = "https://t.me/gas_sniper/5562"

print("""
🎯 Gas Sniper — the best crypto tools for your work!

🔧 Real-world crypto utilities
🧠 Only useful tools
🕶 Maximum automation
📡 Zero noise
""")
print(Fore.GREEN + "More tools 👉🏼 https://t.me/gas_sniper" + Fore.RESET)

webbrowser.open(url)

input("Press Enter for exit...")
